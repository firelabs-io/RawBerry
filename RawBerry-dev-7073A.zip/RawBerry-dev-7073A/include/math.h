#ifndef MATH_H
#define MATH_H
#include "../include/string.h"
#include "../drivers/vga.h"

extern char* itol(int num);
extern int stol(const char* str);

#endif