void printf(char* text);
char* scanf();