#include "stddef.h"
uint8_t Strlen(char* string);
uint8_t strEql(char* s1, char* s2);
char* strSlice(char* source, uint16_t start, uint16_t end);