# Initial kernel stage

Kernel stage when it just started working.