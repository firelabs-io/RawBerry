# Boot folder

Here are stored RawBerry GRUB configuration files. Maybe custom bootloader in the future.