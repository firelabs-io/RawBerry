# RawBerry
RawBerry is a lightweight and simple operating system by [The RawBerry Team](https://github.com/rawberryteam).

> [!NOTE]
> This project is trying to be revived. Join our offical Discord server for support and chat: https://discord.gg/umgMqTaY44

## Features
Actually nothing... We are working hard to create useful features for this OS.



## Languages
- C
- Assembly 
- Rust 
- C++

## Authors

We use our [GitHub organization](https://github.com/RawBerryTeam) to host RawBerry repos. Our team consists of:

- [Gorciu](https://github.com/gorciu-official)
- [Jakyb](https://github.com/Goldjakyt)
- [Eklerka25](https://github.com/Eklerka25)
- [firelabs-io](https://github.com/firelabs-io)
 
The order is not important.

## License
The MIT License.

