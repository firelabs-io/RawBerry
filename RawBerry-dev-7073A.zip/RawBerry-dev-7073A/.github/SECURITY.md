# Security Policy

## Supported Versions

Every version is supported by the community. For now **no one provides official support**.

## Reporting a Security Vulnerability

Email us at `team@rawberry.int.pl`. Anyone from us will inform the rest.
